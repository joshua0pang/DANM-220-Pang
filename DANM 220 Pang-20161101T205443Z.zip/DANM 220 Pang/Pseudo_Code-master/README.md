# Pseudo_Code
Productive Catharsis

A note on reading the text:
The author's preferred reading window is Sublime Text 3 using Espresso Libre syntax highlighting.
However, Github's cloud reading window is perfectly satisfactory.
Syntax highlighting is the feature which colors words funny, like *this*—
```java
this
```
Anytime you are confused by something, Google it. Search Wikipedia. 
That's a good algorithm.
